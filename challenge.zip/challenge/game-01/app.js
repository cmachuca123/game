function findSubsetSum(M, N) {
    var seenNumbers = new Set(); // Usamos un conjunto para almacenar números visitados
    for (var _i = 0, M_1 = M; _i < M_1.length; _i++) {
        var num = M_1[_i];
        var complement = N - num; // Calculamos el complemento que necesitamos
        // Si el complemento ya existe en el conjunto, retornamos el par
        if (seenNumbers.has(complement)) {
            return [complement, num];
        }
        // Agregamos el número actual al conjunto
        seenNumbers.add(num);
    }
    // Si no se encuentra un par, retornamos un array vacío
    return [];
}
// Ejemplo de uso
var M = [2, 5, 8, 14, 0];
var N = 10;
var result = findSubsetSum(M, N);
console.log(result); // Output: [2, 8]
