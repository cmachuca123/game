"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SulfurasStrategy = exports.BackstagePassStrategy = exports.AgedBrieStrategy = exports.NormalItemStrategy = exports.Item = void 0;
var Item = /** @class */ (function () {
    function Item(name, sellIn, quality) {
        this.name = name;
        this.sellIn = sellIn;
        this.quality = quality;
    }
    return Item;
}());
exports.Item = Item;
var NormalItemStrategy = /** @class */ (function () {
    function NormalItemStrategy() {
    }
    NormalItemStrategy.prototype.update = function (item) {
        item.sellIn -= 1;
        item.quality -= item.sellIn < 0 ? 2 : 1;
        item.quality = Math.max(0, item.quality);
    };
    return NormalItemStrategy;
}());
exports.NormalItemStrategy = NormalItemStrategy;
var AgedBrieStrategy = /** @class */ (function () {
    function AgedBrieStrategy() {
    }
    AgedBrieStrategy.prototype.update = function (item) {
        item.sellIn -= 1;
        item.quality += item.sellIn < 0 ? 2 : 1;
        item.quality = Math.min(50, item.quality);
    };
    return AgedBrieStrategy;
}());
exports.AgedBrieStrategy = AgedBrieStrategy;
var BackstagePassStrategy = /** @class */ (function () {
    function BackstagePassStrategy() {
    }
    BackstagePassStrategy.prototype.update = function (item) {
        item.sellIn -= 1;
        if (item.sellIn < 0) {
            item.quality = 0;
        }
        else if (item.sellIn < 5) {
            item.quality += 3;
        }
        else if (item.sellIn < 10) {
            item.quality += 2;
        }
        else {
            item.quality += 1;
        }
        item.quality = Math.min(50, item.quality);
    };
    return BackstagePassStrategy;
}());
exports.BackstagePassStrategy = BackstagePassStrategy;
var SulfurasStrategy = /** @class */ (function () {
    function SulfurasStrategy() {
    }
    SulfurasStrategy.prototype.update = function (item) {
    };
    return SulfurasStrategy;
}());
exports.SulfurasStrategy = SulfurasStrategy;
