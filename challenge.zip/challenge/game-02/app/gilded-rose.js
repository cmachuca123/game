"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GildedRose = void 0;
var ItemStrategyFactory_1 = require("./service/ItemStrategyFactory");
var GildedRose = /** @class */ (function () {
    function GildedRose(items) {
        this.items = items;
    }
    GildedRose.prototype.updateQuality = function () {
        for (var _i = 0, _a = this.items; _i < _a.length; _i++) {
            var item = _a[_i];
            var strategy = ItemStrategyFactory_1.ItemStrategyFactory.getStrategy(item);
            strategy.update(item);
        }
        return this.items;
    };
    return GildedRose;
}());
exports.GildedRose = GildedRose;
