"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ItemStrategyFactory = void 0;
var Item_1 = require("../service/Item");
var ItemStrategyFactory = /** @class */ (function () {
    function ItemStrategyFactory() {
    }
    ItemStrategyFactory.getStrategy = function (item) {
        switch (item.name) {
            case "Aged Brie":
                return new Item_1.AgedBrieStrategy();
            case "Backstage passes to a TAFKAL80ETC concert":
                return new Item_1.BackstagePassStrategy();
            case "Sulfuras, Hand of Ragnaros":
                return new Item_1.SulfurasStrategy();
            default:
                return new Item_1.NormalItemStrategy();
        }
    };
    return ItemStrategyFactory;
}());
exports.ItemStrategyFactory = ItemStrategyFactory;
