import { ItemStrategy } from "../dto/ItemStrategy";

export class Item {
    name: string;
    sellIn: number;
    quality: number;

    constructor(name: string, sellIn: number, quality: number) {
        this.name = name;
        this.sellIn = sellIn;
        this.quality = quality;
    }
}

export class NormalItemStrategy implements ItemStrategy {
    update(item: Item): void {
        item.sellIn -= 1;
        item.quality -= item.sellIn < 0 ? 2 : 1;
        item.quality = Math.max(0, item.quality);
    }
}

export class AgedBrieStrategy implements ItemStrategy {
    update(item: Item): void {
        item.sellIn -= 1;
        item.quality += item.sellIn < 0 ? 2 : 1;
        item.quality = Math.min(50, item.quality);
    }
}

export class BackstagePassStrategy implements ItemStrategy {
    update(item: Item): void {
        item.sellIn -= 1;

        if (item.sellIn < 0) {
            item.quality = 0;
        } else if (item.sellIn < 5) {
            item.quality += 3;
        } else if (item.sellIn < 10) {
            item.quality += 2;
        } else {
            item.quality += 1;
        }

        item.quality = Math.min(50, item.quality);
    }
}

export class SulfurasStrategy implements ItemStrategy {
    update(item: Item): void {
    }
}