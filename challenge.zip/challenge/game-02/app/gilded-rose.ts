import { Item } from "./service/Item";
import { ItemStrategyFactory } from "./service/ItemStrategyFactory";


export class GildedRose {
    items: Array<Item>;

    constructor(items: Array<Item>) {
        this.items = items;
    }

    updateQuality(): Array<Item> {
        for (const item of this.items) {
            const strategy = ItemStrategyFactory.getStrategy(item);
            strategy.update(item);
        }
        return this.items;
    }
}
