function findSubsetSum(M: number[], N: number): number[] {
    const seenNumbers = new Set<number>(); // Usamos un conjunto para almacenar números visitados

    for (let num of M) {
        const complement = N - num; // Calculamos el complemento que necesitamos

        // Si el complemento ya existe en el conjunto, retornamos el par
        if (seenNumbers.has(complement)) {
            return [complement, num];
        }

        // Agregamos el número actual al conjunto
        seenNumbers.add(num);
    }

    // Si no se encuentra un par, retornamos un array vacío
    return [];
}

// Valores de ejemplo
const M = [2, 5, 8, 14, 0];
const N = 10;

const result = findSubsetSum(M, N);
console.log(result); // Output: [2, 8]
