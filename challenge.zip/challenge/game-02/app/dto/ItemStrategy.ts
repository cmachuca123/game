import { Item } from "../service/Item";

export interface ItemStrategy {
    update(item: Item): void;
}