import { ItemStrategy } from "../dto/ItemStrategy";
import { AgedBrieStrategy, BackstagePassStrategy, Item, NormalItemStrategy, SulfurasStrategy } from "../service/Item";


export class ItemStrategyFactory {
    static getStrategy(item: Item): ItemStrategy {
        switch (item.name) {
            case "Aged Brie":
                return new AgedBrieStrategy();
            case "Backstage passes to a TAFKAL80ETC concert":
                return new BackstagePassStrategy();
            case "Sulfuras, Hand of Ragnaros":
                return new SulfurasStrategy();
            default:
                return new NormalItemStrategy();
        }
    }
}